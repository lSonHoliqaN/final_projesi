from django.contrib import admin
from .models import Odev

# Register your models here.
from .models import Odev

admin.site.register(Odev)