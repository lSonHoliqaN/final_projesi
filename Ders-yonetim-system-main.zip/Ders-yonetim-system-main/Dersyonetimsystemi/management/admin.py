from django.contrib import admin
from .models import DersProgrami


admin.site.register(DersProgrami)